package az.developia.bookshopping_veliyev_perviz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookshoppingVeliyevPervizApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookshoppingVeliyevPervizApplication.class, args);
	}

}
