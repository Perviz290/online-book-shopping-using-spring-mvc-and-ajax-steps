package az.developia.bookshopping_veliyev_perviz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshoppingVeliyevPervizApplicationTests {

	@Test
	void contextLoads() {
	}

}
